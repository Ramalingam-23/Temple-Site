# Artha – Temple Website (React + Node/Express + MySQL)

Pages: Login · Signup · Home (hero carousel, Famous Temples, Upcoming Festivals, Book for Darshan, footer)
· Temple Details (overview, Quick Information, Daily Rituals, Major Festivals, Guidelines, Nearby Places)
· Discover (search) · Services · Book Darshan · Booking confirmation (Thank You) · My Bookings · Saved Temples

Stored in MySQL: users (bcrypt-hashed passwords, JWT login), bookmarks, likes, festival reminders, darshan bookings,
plus all temple / festival / ritual / hero content.

## 1. Requirements
- Node.js 18+
- MySQL 8 (or MariaDB 10.5+)

## 2. Database
```bash
mysql -u root -p < backend/database/schema.sql
```
This creates the `artha` database, all tables and the seed content.

## 3. Backend (API on http://localhost:5000)
```bash
cd backend
cp .env.example .env      # then set DB_PASSWORD and JWT_SECRET
npm install
npm run dev
```
Check: http://localhost:5000/api/health  →  `{"ok":true,"db":"connected"}`

## 4. Frontend (http://localhost:5173)
```bash
cd frontend
npm install
npm run dev
```
Vite proxies `/api` to the backend. For production: `npm run build`, serve `dist/`,
and set `VITE_API_URL=https://your-api/api` before building.

## 5. Images
Put your photos in `frontend/public/images/` with these names (a warm placeholder shows until you do):

| File | Used for |
|---|---|
| hero-1.jpg, hero-2.jpg, hero-3.jpg | Home hero carousel |
| kashi.jpg, tirumala.jpg, vrindavan.jpg | Temple cards & detail page |
| janmashtami.jpg, ganesh.jpg, navratri.jpg, diwali.jpg | Festival cards |
| darshan-1.jpg (large), darshan-2.jpg, darshan-3.jpg | Book for Darshan banner |
| auth-login.jpg, auth-signup.jpg | Login / Signup side panels |

Image paths are stored in MySQL (`temples.image`, `festivals.image`, `hero_slides.image`), so you can also use full URLs.

## 6. API summary
| Method | Endpoint | Auth |
|---|---|---|
| POST | /api/auth/signup, /api/auth/login | – |
| GET | /api/auth/me | required |
| GET | /api/slides, /api/festivals, /api/temples?q=, /api/temples/:slug | optional |
| POST | /api/temples/:id/bookmark, /api/temples/:id/like, /api/festivals/:id/remind | required (toggle) |
| GET | /api/me/bookmarks, /api/bookings/mine | required |
| GET | /api/bookings/options, /api/bookings/:ref | – |
| POST | /api/bookings | optional (guests can book) |
| PATCH | /api/bookings/:id/cancel | required |

## 7. Not wired up yet
- **Google / Facebook buttons** show a notice. To enable them, add OAuth (e.g. Passport.js or Firebase Auth) and call `finish()` in `AuthContext`.
- **Forgot Password** shows a notice. Needs an email provider (e.g. Nodemailer + reset-token table).

UI design reference: "Artha – Temple Website UI Design" by Vrunda Raghav on Behance.
