import jwt from 'jsonwebtoken';

const SECRET = () => process.env.JWT_SECRET || 'dev_secret';

export function signToken(user, remember) {
  return jwt.sign({ id: user.id, email: user.email, name: user.full_name }, SECRET(), {
    expiresIn: remember ? '30d' : '1d',
  });
}

function readUser(req) {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Bearer ')) return null;
  try { return jwt.verify(h.slice(7), SECRET()); } catch { return null; }
}

/** Attaches req.user if a valid token is present; never blocks. */
export function optionalAuth(req, _res, next) {
  req.user = readUser(req);
  next();
}

/** Blocks the request unless a valid token is present. */
export function requireAuth(req, res, next) {
  req.user = readUser(req);
  if (!req.user) return res.status(401).json({ message: 'Please log in to continue.' });
  next();
}
