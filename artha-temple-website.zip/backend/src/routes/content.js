import { Router } from 'express';
import { pool } from '../db.js';
import { optionalAuth, requireAuth } from '../auth.js';
import { toggle } from './temples.js';

const r = Router();

r.get('/slides', async (_req, res, next) => {
  try { const [rows] = await pool.query('SELECT * FROM hero_slides ORDER BY sort'); res.json(rows); }
  catch (e) { next(e); }
});

r.get('/festivals', optionalAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      `SELECT f.*, (fr.user_id IS NOT NULL) AS reminded
         FROM festivals f
         LEFT JOIN festival_reminders fr ON fr.festival_id = f.id AND fr.user_id = ?
        ORDER BY f.fest_date`, [req.user?.id || 0]);
    res.json(rows.map((f) => ({ ...f, reminded: !!f.reminded })));
  } catch (e) { next(e); }
});

r.post('/festivals/:id/remind', requireAuth, (req, res, next) =>
  toggle('festival_reminders', 'festival_id', req, res, next));

r.get('/me/bookmarks', requireAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      `SELECT t.id, t.slug, t.name, t.short_desc, t.image, 1 AS bookmarked
         FROM bookmarks b JOIN temples t ON t.id = b.temple_id
        WHERE b.user_id = ? ORDER BY b.created_at DESC`, [req.user.id]);
    res.json(rows.map((t) => ({ ...t, bookmarked: true })));
  } catch (e) { next(e); }
});

export default r;
