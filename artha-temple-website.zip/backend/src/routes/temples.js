import { Router } from 'express';
import { pool } from '../db.js';
import { optionalAuth, requireAuth } from '../auth.js';

const r = Router();

// GET /api/temples?q=&featured=1
r.get('/', optionalAuth, async (req, res, next) => {
  try {
    const { q, featured } = req.query;
    const uid = req.user?.id || 0;
    const where = [];
    const params = [uid];
    if (q) { where.push('(t.name LIKE ? OR t.location LIKE ? OR t.deity LIKE ?)'); params.push(`%${q}%`, `%${q}%`, `%${q}%`); }
    if (featured) where.push('t.featured = 1');
    const [rows] = await pool.query(
      `SELECT t.id, t.slug, t.name, t.short_desc, t.image, t.location, t.deity,
              (b.user_id IS NOT NULL) AS bookmarked
         FROM temples t
         LEFT JOIN bookmarks b ON b.temple_id = t.id AND b.user_id = ?
        ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
        ORDER BY t.id`, params);
    res.json(rows.map((t) => ({ ...t, bookmarked: !!t.bookmarked })));
  } catch (e) { next(e); }
});

// GET /api/temples/:slug
r.get('/:slug', optionalAuth, async (req, res, next) => {
  try {
    const uid = req.user?.id || 0;
    const [rows] = await pool.query(
      `SELECT t.*, (b.user_id IS NOT NULL) AS bookmarked, (l.user_id IS NOT NULL) AS liked,
              (SELECT COUNT(*) FROM temple_likes WHERE temple_id = t.id) AS like_count
         FROM temples t
         LEFT JOIN bookmarks b ON b.temple_id = t.id AND b.user_id = ?
         LEFT JOIN temple_likes l ON l.temple_id = t.id AND l.user_id = ?
        WHERE t.slug = ?`, [uid, uid, req.params.slug]);
    const temple = rows[0];
    if (!temple) return res.status(404).json({ message: 'Temple not found.' });
    const id = temple.id;
    const [[rituals], [festivals], [guidelines], [nearby]] = await Promise.all([
      pool.query('SELECT * FROM rituals WHERE temple_id = ? ORDER BY sort', [id]),
      pool.query('SELECT * FROM temple_festivals WHERE temple_id = ?', [id]),
      pool.query('SELECT * FROM guidelines WHERE temple_id = ?', [id]),
      pool.query('SELECT * FROM nearby_places WHERE temple_id = ?', [id]),
    ]);
    res.json({ ...temple, bookmarked: !!temple.bookmarked, liked: !!temple.liked, rituals, festivals, guidelines, nearby });
  } catch (e) { next(e); }
});

async function toggle(table, col, req, res, next) {
  try {
    const uid = req.user.id; const id = Number(req.params.id);
    const [del] = await pool.query(`DELETE FROM ${table} WHERE user_id = ? AND ${col} = ?`, [uid, id]);
    if (del.affectedRows) return res.json({ active: false });
    await pool.query(`INSERT INTO ${table} (user_id, ${col}) VALUES (?, ?)`, [uid, id]);
    res.json({ active: true });
  } catch (e) { next(e); }
}

r.post('/:id/bookmark', requireAuth, (req, res, next) => toggle('bookmarks', 'temple_id', req, res, next));
r.post('/:id/like', requireAuth, (req, res, next) => toggle('temple_likes', 'temple_id', req, res, next));

export { toggle };
export default r;
