import { Router } from 'express';
import { pool } from '../db.js';
import { optionalAuth, requireAuth } from '../auth.js';

const r = Router();
export const TIME_SLOTS = ['04:00 AM – 06:00 AM', '06:00 AM – 09:00 AM', '09:00 AM – 12:00 PM', '04:00 PM – 07:00 PM', '07:00 PM – 09:00 PM'];
export const DARSHAN_TYPES = ['General Darshan', 'Special Entry Darshan', 'VIP Darshan', 'Aarti Darshan'];

const makeRef = () => 'ART' + Date.now().toString(36).toUpperCase().slice(-6) + Math.floor(Math.random() * 90 + 10);

r.get('/options', (_req, res) => res.json({ timeSlots: TIME_SLOTS, darshanTypes: DARSHAN_TYPES }));

r.post('/', optionalAuth, async (req, res, next) => {
  try {
    const { templeId, fullName, email, phone, visitDate, timeSlot, darshanType, devotees } = req.body;
    if (!templeId || !fullName || !email || !phone || !visitDate || !timeSlot || !darshanType)
      return res.status(400).json({ message: 'Please fill all the required fields.' });
    if (!/^[0-9+\s-]{8,15}$/.test(phone)) return res.status(400).json({ message: 'Enter a valid phone number.' });
    const count = Number(devotees) || 1;
    if (count < 1 || count > 10) return res.status(400).json({ message: 'You can book for 1 to 10 devotees.' });
    const today = new Date().toISOString().slice(0, 10);
    if (visitDate < today) return res.status(400).json({ message: 'Visit date cannot be in the past.' });
    if (!TIME_SLOTS.includes(timeSlot) || !DARSHAN_TYPES.includes(darshanType))
      return res.status(400).json({ message: 'Invalid slot or darshan type.' });

    const ref = makeRef();
    const [result] = await pool.query(
      `INSERT INTO bookings (booking_ref, user_id, temple_id, full_name, email, phone, visit_date, time_slot, darshan_type, devotees)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [ref, req.user?.id || null, templeId, fullName, email, phone, visitDate, timeSlot, darshanType, count]);
    const [rows] = await pool.query(
      `SELECT b.*, t.name AS temple_name FROM bookings b JOIN temples t ON t.id = b.temple_id WHERE b.id = ?`, [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
});

r.get('/mine', requireAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      `SELECT b.*, t.name AS temple_name, t.image AS temple_image, t.slug AS temple_slug
         FROM bookings b JOIN temples t ON t.id = b.temple_id
        WHERE b.user_id = ? ORDER BY b.visit_date DESC`, [req.user.id]);
    res.json(rows);
  } catch (e) { next(e); }
});

r.get('/:ref', async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      `SELECT b.*, t.name AS temple_name FROM bookings b JOIN temples t ON t.id = b.temple_id WHERE b.booking_ref = ?`, [req.params.ref]);
    if (!rows[0]) return res.status(404).json({ message: 'Booking not found.' });
    res.json(rows[0]);
  } catch (e) { next(e); }
});

r.patch('/:id/cancel', requireAuth, async (req, res, next) => {
  try {
    const [u] = await pool.query(`UPDATE bookings SET status = 'CANCELLED' WHERE id = ? AND user_id = ?`, [req.params.id, req.user.id]);
    if (!u.affectedRows) return res.status(404).json({ message: 'Booking not found.' });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

export default r;
