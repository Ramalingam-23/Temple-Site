-- =========================================================
--  Artha – Temple Website  |  MySQL schema + seed data
--  Run:  mysql -u root -p < database/schema.sql
-- =========================================================
SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS artha CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE artha;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS bookings, festival_reminders, temple_likes, bookmarks,
  nearby_places, guidelines, temple_festivals, rituals, festivals, hero_slides, temples, users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------- Users ----------
CREATE TABLE users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(120) NOT NULL,
  email         VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------- Home hero carousel ----------
CREATE TABLE hero_slides (
  id       INT AUTO_INCREMENT PRIMARY KEY,
  title    VARCHAR(200) NOT NULL,
  subtitle VARCHAR(300) NOT NULL,
  image    VARCHAR(300) NOT NULL,
  sort     INT DEFAULT 0
);

-- ---------- Temples ----------
CREATE TABLE temples (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  slug             VARCHAR(120) NOT NULL UNIQUE,
  name             VARCHAR(150) NOT NULL,
  short_desc       VARCHAR(255) NOT NULL,
  description      TEXT NOT NULL,
  image            VARCHAR(300) NOT NULL,
  location         VARCHAR(200),
  deity            VARCHAR(200),
  established      VARCHAR(200),
  established_note VARCHAR(255),
  timings          VARCHAR(100),
  timings_note     VARCHAR(255),
  entry_fee        VARCHAR(100),
  entry_fee_note   VARCHAR(255),
  best_time        VARCHAR(100),
  best_time_note   VARCHAR(255),
  video_url        VARCHAR(300),
  featured         TINYINT(1) DEFAULT 0,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE rituals (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  temple_id   INT NOT NULL,
  icon        VARCHAR(16),
  title       VARCHAR(150) NOT NULL,
  time_label  VARCHAR(80),
  description VARCHAR(400),
  sort        INT DEFAULT 0,
  FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE CASCADE
);

CREATE TABLE temple_festivals (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  temple_id   INT NOT NULL,
  name        VARCHAR(150) NOT NULL,
  period      VARCHAR(80),
  description VARCHAR(400),
  FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE CASCADE
);

CREATE TABLE guidelines (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  temple_id INT NOT NULL,
  text      VARCHAR(300) NOT NULL,
  FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE CASCADE
);

CREATE TABLE nearby_places (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  temple_id   INT NOT NULL,
  name        VARCHAR(150) NOT NULL,
  distance    VARCHAR(50),
  description VARCHAR(300),
  FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE CASCADE
);

-- ---------- Festivals ----------
CREATE TABLE festivals (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  fest_date   DATE NOT NULL,
  description VARCHAR(300),
  image       VARCHAR(300)
);

-- ---------- User interactions ----------
CREATE TABLE bookmarks (
  user_id    INT NOT NULL,
  temple_id  INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, temple_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE CASCADE
);

CREATE TABLE temple_likes (
  user_id    INT NOT NULL,
  temple_id  INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, temple_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE CASCADE
);

CREATE TABLE festival_reminders (
  user_id     INT NOT NULL,
  festival_id INT NOT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, festival_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (festival_id) REFERENCES festivals(id) ON DELETE CASCADE
);

CREATE TABLE bookings (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  booking_ref  VARCHAR(20) NOT NULL UNIQUE,
  user_id      INT NULL,
  temple_id    INT NOT NULL,
  full_name    VARCHAR(120) NOT NULL,
  email        VARCHAR(190) NOT NULL,
  phone        VARCHAR(20) NOT NULL,
  visit_date   DATE NOT NULL,
  time_slot    VARCHAR(40) NOT NULL,
  darshan_type VARCHAR(60) NOT NULL,
  devotees     INT NOT NULL DEFAULT 1,
  status       VARCHAR(20) NOT NULL DEFAULT 'CONFIRMED',
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE CASCADE
);

-- =========================================================
--  SEED DATA
-- =========================================================
INSERT INTO hero_slides (title, subtitle, image, sort) VALUES
('Discover the Sacred Heritage of India', 'Explore ancient temples, their history, architecture, and spiritual significance - all in one place.', '/images/hero-1.jpg', 1),
('Celebrate Every Festival with Devotion', 'Learn why festivals are celebrated, the rituals they involve, and the traditions behind them.', '/images/hero-2.jpg', 2),
('Book Your Darshan in a Few Taps', 'Plan a peaceful and seamless visit to the temples you love.', '/images/hero-3.jpg', 3);

INSERT INTO temples (id, slug, name, short_desc, description, image, location, deity, established, established_note,
  timings, timings_note, entry_fee, entry_fee_note, best_time, best_time_note, video_url, featured) VALUES
(1, 'kashi-vishwanath', 'Kashi Vishwanath', 'One of the Twelve Sacred Jyotirlingas.',
 'Kashi Vishwanath Temple, situated on the banks of the sacred Ganga in Varanasi, is one of the most revered temples dedicated to Lord Shiva. As one of the twelve Jyotirlingas, it symbolizes divine light and spiritual liberation. For centuries, devotees from across the world have visited this holy shrine to seek blessings, perform rituals, and experience the city''s deep spiritual heritage.',
 '/images/kashi.jpg', 'Varanasi, Uttar Pradesh, India', 'Lord Shiva (Vishwanath)', 'Ancient temple', '(current structure rebuilt in 1780 CE)',
 '3:00 AM – 11:00 PM', '(may vary during festivals and special occasions)', 'Free', '(Special services may be chargeable)',
 'October – March', 'Maha Shivaratri and Dev Deepawali are especially popular', 'https://www.youtube.com/results?search_query=kashi+vishwanath+aarti', 1),
(2, 'tirumala', 'Tirumala', 'A Divine Destination for Millions of Devotees.',
 'Sri Venkateswara Temple at Tirumala, nestled in the Seshachalam hills of Andhra Pradesh, is dedicated to Lord Venkateswara, a form of Lord Vishnu. It is one of the most visited pilgrimage centres in the world, known for its Dravidian architecture, the sacred laddu prasadam and the devotion of millions who climb the holy hills every year.',
 '/images/tirumala.jpg', 'Tirupati, Andhra Pradesh, India', 'Lord Venkateswara (Vishnu)', 'Ancient temple', '(earliest records from 300 CE)',
 '3:00 AM – 12:00 AM', '(Suprabhatam to Ekantha Seva)', 'Free (Sarva Darshan)', '(Special Entry ₹300)',
 'September – February', 'Brahmotsavam draws devotees from across the world', 'https://www.youtube.com/results?search_query=tirumala+temple', 1),
(3, 'vrindavan', 'Vrindavan', 'The Sacred Land of Lord Krishna.',
 'Vrindavan, on the banks of the Yamuna, is the land where Lord Krishna spent his childhood. The town is home to thousands of temples, including Banke Bihari, ISKCON and Prem Mandir, and resonates with bhajans, kirtans and the timeless stories of Radha and Krishna.',
 '/images/vrindavan.jpg', 'Mathura, Uttar Pradesh, India', 'Lord Krishna & Radha Rani', 'Ancient sacred town', '(many temples built 16th–21st century)',
 '5:00 AM – 9:00 PM', '(temples close in the afternoon)', 'Free', '(Donations welcome)',
 'October – March', 'Holi and Janmashtami are celebrated grandly', 'https://www.youtube.com/results?search_query=vrindavan+temples', 1);

INSERT INTO rituals (temple_id, icon, title, time_label, description, sort) VALUES
(1, '🌅', 'Mangala Aarti', 'Early Morning', 'The first prayer of the day, performed before sunrise to awaken and worship Lord Shiva with devotion.', 1),
(1, '🛕', 'Rudrabhishekam', 'Morning', 'Lord Shiva is bathed with holy offerings while sacred mantras are chanted.', 2),
(1, '💐', 'Shringar & Bhog', 'Morning', 'The deity is beautifully adorned with flowers and ornaments, followed by the offering of sacred food (Bhog).', 3),
(1, '🪔', 'Saptarishi Aarti', 'Evening', 'Performed by seven priests representing the Saptarishis, filling the temple with divine chants.', 4),
(1, '🌙', 'Shayan Aarti', 'Night', 'The final aarti of the day, putting the Lord to rest with soothing hymns.', 5),
(2, '🌅', 'Suprabhatam', 'Early Morning', 'Sacred hymns are sung to awaken Lord Venkateswara at dawn.', 1),
(2, '🪔', 'Thomala Seva', 'Morning', 'The deity is decorated with fresh flower garlands.', 2),
(2, '🌙', 'Ekantha Seva', 'Night', 'The final ritual where the Lord is put to rest.', 3),
(3, '🌅', 'Mangala Aarti', 'Early Morning', 'The day begins with aarti and kirtan for Radha Krishna.', 1),
(3, '💐', 'Shringar Darshan', 'Morning', 'The deities are dressed in beautiful attire and jewellery.', 2),
(3, '🪔', 'Sandhya Aarti', 'Evening', 'Evening aarti accompanied by bhajans along the Yamuna.', 3);

INSERT INTO temple_festivals (temple_id, name, period, description) VALUES
(1, 'Maha Shivaratri', 'February / March', 'The great night of Shiva, celebrated with night-long prayers and abhishekam.'),
(1, 'Dev Deepawali', 'November', 'The ghats of Varanasi glow with millions of diyas on Kartik Purnima.'),
(1, 'Shravan Maas', 'July / August', 'The holy month of Shiva when devotees offer Ganga jal every Monday.'),
(2, 'Brahmotsavam', 'September / October', 'A nine-day grand festival with processions of the Lord on different vahanas.'),
(2, 'Vaikunta Ekadasi', 'December / January', 'Devotees pass through the sacred Vaikunta Dwaram.'),
(3, 'Janmashtami', 'August / September', 'The birth of Lord Krishna celebrated at midnight with joy and devotion.'),
(3, 'Holi', 'March', 'The festival of colours, played with flowers and gulal in Vrindavan.');

INSERT INTO guidelines (temple_id, text) VALUES
(1, 'Wear traditional and modest clothing.'), (1, 'Mobile phones, cameras and leather items are not allowed inside.'),
(1, 'Carry a valid photo ID for darshan booking.'), (1, 'Maintain silence and follow queue discipline.'),
(2, 'Traditional dress code is mandatory.'), (2, 'Carry the darshan ticket and ID proof.'), (2, 'Electronic items are not permitted.'),
(3, 'Remove footwear before entering temples.'), (3, 'Beware of monkeys – keep spectacles and bags secure.');

INSERT INTO nearby_places (temple_id, name, distance, description) VALUES
(1, 'Dashashwamedh Ghat', '0.5 km', 'Famous for the grand evening Ganga Aarti.'),
(1, 'Manikarnika Ghat', '0.8 km', 'One of the oldest and most sacred ghats.'),
(1, 'Sarnath', '10 km', 'Where Lord Buddha gave his first sermon.'),
(2, 'Sri Padmavathi Temple', '25 km', 'Dedicated to Goddess Padmavathi, consort of Lord Venkateswara.'),
(2, 'Akasa Ganga', '3 km', 'A sacred waterfall near the main temple.'),
(3, 'Prem Mandir', '2 km', 'A beautiful white marble temple, illuminated at night.'),
(3, 'Mathura Janmabhoomi', '12 km', 'The birthplace of Lord Krishna.');

INSERT INTO festivals (name, fest_date, description, image) VALUES
('Janmashtami',     '2026-09-04', 'Experience Krishna''s timeless legacy.',      '/images/janmashtami.jpg'),
('Ganesh Chaturthi','2026-09-14', 'Celebrate new beginnings and blessings.',     '/images/ganesh.jpg'),
('Navratri',        '2026-10-11', 'Honor the divine power of Goddess Durga.',    '/images/navratri.jpg'),
('Diwali',          '2026-11-08', 'Light the path to joy and prosperity.',       '/images/diwali.jpg');
