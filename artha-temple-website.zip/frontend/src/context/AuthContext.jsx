import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { api, tokenStore } from '../api';

const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [guest, setGuest] = useState(() => sessionStorage.getItem('artha_guest') === '1');
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!tokenStore.get()) { setReady(true); return; }
    api.me().then((d) => setUser(d.user)).catch(() => tokenStore.clear()).finally(() => setReady(true));
  }, []);

  const finish = (d, remember) => {
    tokenStore.set(d.token, remember);
    sessionStorage.removeItem('artha_guest');
    setGuest(false);
    setUser(d.user);
  };
  const login = useCallback(async (b) => finish(await api.login(b), b.remember), []);
  const signup = useCallback(async (b) => finish(await api.signup(b), b.remember), []);
  const continueAsGuest = () => { sessionStorage.setItem('artha_guest', '1'); setGuest(true); };
  const logout = () => { tokenStore.clear(); sessionStorage.removeItem('artha_guest'); setUser(null); setGuest(false); };

  return (
    <AuthCtx.Provider value={{ user, guest, ready, login, signup, logout, continueAsGuest }}>
      {children}
    </AuthCtx.Provider>
  );
}

export const useAuth = () => useContext(AuthCtx);
