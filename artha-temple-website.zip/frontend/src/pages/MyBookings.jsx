import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Img from '../components/Img';
import { api } from '../api';
import { fmtDate } from '../components/Cards';
import { useAuth } from '../context/AuthContext';
import { toast } from '../components/Toast';
import { Calendar, Clock, Users } from '../components/Icons';

export default function MyBookings() {
  const { user } = useAuth();
  const [list, setList] = useState(null);
  useEffect(() => { if (user) api.myBookings().then(setList).catch(() => setList([])); }, [user]);

  const cancel = async (id) => {
    if (!window.confirm('Cancel this booking?')) return;
    await api.cancelBooking(id);
    setList((l) => l.map((b) => (b.id === id ? { ...b, status: 'CANCELLED' } : b)));
    toast('Booking cancelled');
  };

  return (
    <div className="page">
      <div className="detail-wrap">
        <Navbar />
        <div className="page-head"><h1><span className="accent">My</span> Bookings</h1></div>
        {!user ? <p className="empty">Please <Link to="/login">log in</Link> to see your bookings.</p>
          : list === null ? <div className="page-loader">Loading…</div>
          : list.length === 0 ? <p className="empty">No bookings yet. <Link to="/book">Book a darshan</Link></p>
          : (
            <div className="list">
              {list.map((b) => (
                <div className="panel booking-row" key={b.id}>
                  <Img src={b.temple_image} alt="" className="booking-row__img" />
                  <div className="booking-row__body">
                    <h3><Link to={`/temples/${b.temple_slug}`}>{b.temple_name}</Link> <span className={`status status--${b.status.toLowerCase()}`}>{b.status}</span></h3>
                    <p className="muted">{b.darshan_type} · Ref {b.booking_ref}</p>
                    <p className="booking-row__meta">
                      <span><Calendar size={16} /> {fmtDate(b.visit_date)}</span>
                      <span><Clock size={16} /> {b.time_slot}</span>
                      <span><Users size={16} /> {b.devotees}</span>
                    </p>
                  </div>
                  {b.status === 'CONFIRMED' && <button className="btn-outline" onClick={() => cancel(b.id)}>Cancel</button>}
                </div>
              ))}
            </div>
          )}
      </div>
      <Footer />
    </div>
  );
}
