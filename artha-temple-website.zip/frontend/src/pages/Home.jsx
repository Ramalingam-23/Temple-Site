import { useEffect, useState, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Img from '../components/Img';
import DarshanBanner from '../components/DarshanBanner';
import { TempleCard, FestivalCard } from '../components/Cards';
import { ChevronLeft, ChevronRight } from '../components/Icons';
import { api } from '../api';

const FALLBACK_SLIDES = [{ id: 0, title: 'Discover the Sacred Heritage of India', subtitle: 'Explore ancient temples, their history, architecture, and spiritual significance - all in one place.', image: '/images/hero-1.jpg' }];

export default function Home() {
  const nav = useNavigate();
  const { hash } = useLocation();
  const [slides, setSlides] = useState(FALLBACK_SLIDES);
  const [idx, setIdx] = useState(0);
  const [temples, setTemples] = useState([]);
  const [festivals, setFestivals] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api.slides().then((s) => s.length && setSlides(s)).catch(() => {});
    api.temples({ featured: 1 }).then(setTemples).catch((e) => setError(e.message));
    api.festivals().then(setFestivals).catch(() => {});
  }, []);

  useEffect(() => {
    if (hash) setTimeout(() => document.querySelector(hash)?.scrollIntoView({ behavior: 'smooth' }), 200);
  }, [hash]);

  const go = useCallback((d) => setIdx((i) => (i + d + slides.length) % slides.length), [slides.length]);
  useEffect(() => { const t = setInterval(() => go(1), 6000); return () => clearInterval(t); }, [go]);

  const slide = slides[idx];
  const replace = (setter) => (item) => setter((list) => list.map((x) => (x.id === item.id ? item : x)));

  return (
    <div className="page">
      {/* ---------- Hero ---------- */}
      <section className="hero">
        {slides.map((s, i) => (
          <Img key={s.id} src={s.image} alt="" className={`hero__bg ${i === idx ? 'is-active' : ''}`} />
        ))}
        <div className="hero__overlay" />
        <Navbar className="navbar--floating" />
        <button className="hero__arrow hero__arrow--l" onClick={() => go(-1)} aria-label="Previous slide"><ChevronLeft size={22} sw={2.6} /></button>
        <button className="hero__arrow hero__arrow--r" onClick={() => go(1)} aria-label="Next slide"><ChevronRight size={22} sw={2.6} /></button>
        <div className="hero__content" key={idx}>
          <h1>{slide.title}</h1>
          <p>{slide.subtitle}</p>
          <div className="hero__ctas">
            <button className="btn-primary" onClick={() => nav('/discover')}>Explore Temples <ChevronRight size={18} sw={2.6} /></button>
            <button className="btn-light" onClick={() => document.getElementById('temples')?.scrollIntoView({ behavior: 'smooth' })}>Learn more</button>
          </div>
        </div>
        <div className="hero__dots">
          {slides.map((s, i) => <button key={s.id} className={i === idx ? 'is-active' : ''} onClick={() => setIdx(i)} aria-label={`Slide ${i + 1}`} />)}
        </div>
      </section>

      {/* ---------- Famous temples ---------- */}
      <section className="section" id="temples">
        <h2 className="section__title">Famous Temples</h2>
        {error && <p className="form-error">Could not load temples: {error}. Is the API running?</p>}
        <div className="grid grid--3">
          {temples.map((t) => <TempleCard key={t.id} temple={t} onChange={replace(setTemples)} />)}
        </div>
      </section>

      {/* ---------- Festivals ---------- */}
      <section className="section" id="festivals">
        <h2 className="section__title">Upcoming Festivals</h2>
        <p className="section__sub">Learn why festivals are celebrated, the rituals they involve, and the traditions behind them.</p>
        <div className="grid grid--4">
          {festivals.map((f) => <FestivalCard key={f.id} fest={f} onChange={replace(setFestivals)} />)}
        </div>
      </section>

      <DarshanBanner />
      <Footer />
    </div>
  );
}
