import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Img from '../components/Img';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';
import { User, Mail, Phone, Calendar, Clock, Ticket, Users, TempleIcon } from '../components/Icons';

const today = () => new Date().toISOString().slice(0, 10);

export default function BookDarshan() {
  const nav = useNavigate();
  const [params] = useSearchParams();
  const { user } = useAuth();
  const [temples, setTemples] = useState([]);
  const [opts, setOpts] = useState({ timeSlots: [], darshanTypes: [] });
  const [form, setForm] = useState({
    templeId: params.get('temple') || '', fullName: user?.fullName || '', email: user?.email || '',
    phone: '', visitDate: '', timeSlot: '', darshanType: '', devotees: 1,
  });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.temples().then((l) => { setTemples(l); setForm((f) => ({ ...f, templeId: f.templeId || String(l[0]?.id || '') })); });
    api.bookingOptions().then((o) => { setOpts(o); setForm((f) => ({ ...f, timeSlot: o.timeSlots[0], darshanType: o.darshanTypes[0] })); });
  }, []);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const temple = temples.find((t) => String(t.id) === String(form.templeId));

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      const b = await api.createBooking({ ...form, devotees: Number(form.devotees) });
      nav(`/booking/${b.booking_ref}`);
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };

  return (
    <div className="page">
      <div className="detail-wrap">
        <Navbar />
        <div className="page-head">
          <h1><span className="accent">Book</span> Darshan</h1>
          <p>Experience a peaceful and seamless darshan. Fill in the details below to reserve your slot.</p>
        </div>

        <div className="booking">
          <form className="panel booking__form" onSubmit={submit}>
            <h2 className="panel__title">Darshan Details</h2>
            <div className="form-grid">
              <label className="field field--select"><TempleIcon size={18} />
                <select value={form.templeId} onChange={set('templeId')} required>
                  {temples.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </label>
              <label className="field field--select"><Ticket size={18} />
                <select value={form.darshanType} onChange={set('darshanType')}>{opts.darshanTypes.map((d) => <option key={d}>{d}</option>)}</select>
              </label>
              <label className="field"><Calendar size={18} />
                <input type="date" min={today()} value={form.visitDate} onChange={set('visitDate')} required />
              </label>
              <label className="field field--select"><Clock size={18} />
                <select value={form.timeSlot} onChange={set('timeSlot')}>{opts.timeSlots.map((s) => <option key={s}>{s}</option>)}</select>
              </label>
            </div>

            <h2 className="panel__title">Devotee Details</h2>
            <div className="form-grid">
              <label className="field"><User size={18} /><input placeholder="Enter full name" value={form.fullName} onChange={set('fullName')} required /></label>
              <label className="field"><Mail size={18} /><input type="email" placeholder="Enter email address" value={form.email} onChange={set('email')} required /></label>
              <label className="field"><Phone size={18} /><input type="tel" placeholder="Enter phone number" value={form.phone} onChange={set('phone')} required /></label>
              <label className="field"><Users size={18} /><input type="number" min="1" max="10" placeholder="No. of devotees" value={form.devotees} onChange={set('devotees')} required /></label>
            </div>

            {error && <p className="form-error">{error}</p>}
            <div className="booking__actions">
              <button type="button" className="btn-outline" onClick={() => nav(-1)}>Cancel</button>
              <button className="btn-primary" disabled={busy}>{busy ? 'Booking…' : 'Confirm Booking'}</button>
            </div>
          </form>

          <aside className="panel booking__summary">
            {temple && <Img src={temple.image} alt={temple.name} className="booking__img" />}
            <h3>{temple?.name || 'Select a temple'}</h3>
            <p className="muted">{temple?.location}</p>
            <dl>
              <dt>Darshan</dt><dd>{form.darshanType}</dd>
              <dt>Date</dt><dd>{form.visitDate || '—'}</dd>
              <dt>Slot</dt><dd>{form.timeSlot}</dd>
              <dt>Devotees</dt><dd>{form.devotees}</dd>
            </dl>
            {!user && <p className="note">Booking as guest. <a href="/login">Log in</a> to see your bookings later.</p>}
          </aside>
        </div>
      </div>
      <Footer />
    </div>
  );
}
