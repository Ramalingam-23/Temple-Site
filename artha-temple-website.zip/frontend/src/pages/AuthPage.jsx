import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LogoMark } from '../components/Logo';
import Img from '../components/Img';
import { toast } from '../components/Toast';
import { Mail, Lock, Eye, EyeOff, User, UserPlus, ChevronLeft, GoogleIcon, FacebookIcon } from '../components/Icons';

function Field({ icon: Icon, type = 'text', toggle, ...props }) {
  const [show, setShow] = useState(false);
  const t = toggle ? (show ? 'text' : 'password') : type;
  return (
    <label className="field">
      <Icon size={18} />
      <input type={t} {...props} />
      {toggle && (
        <button type="button" className="field__eye" onClick={() => setShow((s) => !s)} aria-label={show ? 'Hide password' : 'Show password'}>
          {show ? <EyeOff size={20} /> : <Eye size={20} />}
        </button>
      )}
    </label>
  );
}

function SidePanel({ mode, onSwitch }) {
  const login = mode === 'login';
  return (
    <aside className="auth__panel">
      <Img src={login ? '/images/auth-login.jpg' : '/images/auth-signup.jpg'} alt="" className="auth__panel-img" />
      <div className="auth__panel-overlay" />
      <div className="auth__panel-content">
        <LogoMark size={74} color="#fff" ring="#fff" bg="rgba(0,0,0,.15)" />
        <h2>{login ? 'Begin your journey with Artha' : 'Welcome back to Artha'}</h2>
        <p>{login ? 'Create an account to explore temples, rituals, festivals, and more.' : 'Continue your journey through temples, traditions, and rituals.'}</p>
        <button className="btn-ghost-light" onClick={onSwitch}>{login ? 'Create Account' : 'Log In'}</button>
      </div>
    </aside>
  );
}

export default function AuthPage({ mode }) {
  const isLogin = mode === 'login';
  const nav = useNavigate();
  const loc = useLocation();
  const { login, signup, continueAsGuest } = useAuth();
  const [form, setForm] = useState({ fullName: '', email: '', password: '', confirmPassword: '', remember: false });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));
  const valid = isLogin
    ? form.email && form.password
    : form.fullName && form.email && form.password && form.confirmPassword;
  const after = loc.state?.from || '/';

  const submit = async (e) => {
    e.preventDefault();
    if (!valid || busy) return;
    if (!isLogin && form.password !== form.confirmPassword) return setError('Passwords do not match.');
    setBusy(true); setError('');
    try {
      if (isLogin) await login(form); else await signup(form);
      toast(isLogin ? 'Welcome back! 🙏' : 'Account created successfully 🙏');
      nav(after, { replace: true });
    } catch (err) {
      setError(err.message);
    } finally { setBusy(false); }
  };

  const guest = () => { continueAsGuest(); nav('/', { replace: true }); };
  const social = (p) => toast(`${p} sign-in needs OAuth keys – see README to enable it.`);
  const switchMode = () => { setError(''); nav(isLogin ? '/signup' : '/login'); };

  return (
    <div className="auth">
      <span className="deco-squares deco-squares--tr" aria-hidden="true" />
      <span className="deco-squares deco-squares--bl" aria-hidden="true" />
      <svg className="deco-swirl" viewBox="0 0 160 500" aria-hidden="true">
        <path d="M10 10 C 90 40, 110 120, 100 170 C 90 230, 40 230, 45 190 C 50 150, 120 160, 135 220 C 150 300, 120 400, 20 490" />
      </svg>

      <div className={`auth__card ${isLogin ? '' : 'auth__card--reverse'}`}>
        <SidePanel mode={mode} onSwitch={switchMode} />

        <section className="auth__form-wrap">
          <form className="auth__form" onSubmit={submit} noValidate>
            <button type="button" className="auth__title" onClick={() => nav(-1)}>
              <ChevronLeft size={20} sw={2.4} /> {isLogin ? 'Login' : 'Create Account'}
            </button>

            {!isLogin && <Field icon={User} placeholder="Enter full name" value={form.fullName} onChange={set('fullName')} autoComplete="name" />}
            <Field icon={Mail} type="email" placeholder="Enter email address" value={form.email} onChange={set('email')} autoComplete="email" />
            <Field icon={Lock} toggle placeholder="Enter password" value={form.password} onChange={set('password')} autoComplete={isLogin ? 'current-password' : 'new-password'} />
            {!isLogin && <Field icon={Lock} toggle placeholder="Confirm password" value={form.confirmPassword} onChange={set('confirmPassword')} autoComplete="new-password" />}

            <div className="auth__row">
              <label className="check">
                <input type="checkbox" checked={form.remember} onChange={set('remember')} />
                <span className="check__box" /> Remember me
              </label>
              {isLogin && <button type="button" className="link-underline" onClick={() => toast('Password reset link will be sent to your email.')}>Forgot Password?</button>}
            </div>

            {error && <p className="form-error">{error}</p>}

            <div className="auth__row auth__row--actions">
              <button type="button" className="guest-btn" onClick={guest}><UserPlus size={18} /> Continue as Guest</button>
              <button type="submit" className={`btn-submit ${valid ? 'is-active' : ''}`} disabled={!valid || busy}>
                {busy ? 'Please wait…' : isLogin ? 'Login' : 'Signup'}
              </button>
            </div>

            <div className="divider"><span>Or</span></div>

            <div className="social">
              <button type="button" onClick={() => social('Google')}><GoogleIcon /> Google</button>
              <button type="button" onClick={() => social('Facebook')}><FacebookIcon /> Facebook</button>
            </div>
          </form>
        </section>
      </div>
    </div>
  );
}
