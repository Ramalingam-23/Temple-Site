import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import DarshanBanner from '../components/DarshanBanner';
import { Ticket, Users, TempleIcon, FileText, Calendar, ArrowRight } from '../components/Icons';
import { toast } from '../components/Toast';

const SERVICES = [
  { icon: Ticket, title: 'Darshan Booking', desc: 'Reserve your darshan slot in advance and skip the long queues.', to: '/book' },
  { icon: Users, title: 'Purohit Booking', desc: 'Book experienced priests for pujas, homams and ceremonies.' },
  { icon: TempleIcon, title: 'Seva Booking', desc: 'Participate in special sevas and offerings at the temple.' },
  { icon: FileText, title: 'Temple Information', desc: 'History, timings, rituals and guidelines for every temple.', to: '/discover' },
  { icon: Calendar, title: 'Festival Stories', desc: 'Discover the meaning and traditions behind every festival.', to: '/#festivals' },
];

export default function Services() {
  const nav = useNavigate();
  return (
    <div className="page">
      <div className="detail-wrap">
        <Navbar />
        <div className="page-head">
          <h1><span className="accent">Our</span> Services</h1>
          <p>Everything you need for a peaceful and seamless temple experience.</p>
        </div>
        <div className="grid grid--3">
          {SERVICES.map(({ icon: I, title, desc, to }) => (
            <button key={title} className="service-card" onClick={() => (to ? nav(to) : toast(`${title} is coming soon 🙏`))}>
              <span className="service-card__icon"><I size={26} /></span>
              <h3>{title}</h3>
              <p>{desc}</p>
              <span className="service-card__go">{to ? 'Open' : 'Coming soon'} <ArrowRight size={16} /></span>
            </button>
          ))}
        </div>
      </div>
      <DarshanBanner />
      <Footer />
    </div>
  );
}
