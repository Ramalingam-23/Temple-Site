import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { TempleCard } from '../components/Cards';
import { Search } from '../components/Icons';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';

export default function Discover() {
  const [params, setParams] = useSearchParams();
  const { user } = useAuth();
  const q = params.get('q') || '';
  const saved = params.get('saved') === '1';
  const [list, setList] = useState(null);
  const [term, setTerm] = useState(q);

  useEffect(() => {
    setTerm(q);
    setList(null);
    const req = saved && user ? api.myBookmarks() : api.temples(q ? { q } : {});
    req.then(setList).catch(() => setList([]));
  }, [q, saved, user]);

  const replace = (item) => setList((l) => (saved && !item.bookmarked ? l.filter((x) => x.id !== item.id) : l.map((x) => (x.id === item.id ? item : x))));

  return (
    <div className="page">
      <div className="detail-wrap">
        <Navbar />
        <div className="page-head">
          <h1><span className="accent">{saved ? 'Saved' : 'Discover'}</span> Temples</h1>
          <p>{saved ? 'Temples you have bookmarked.' : 'Search India’s sacred temples by name, city or deity.'}</p>
          {!saved && (
            <form className="big-search" onSubmit={(e) => { e.preventDefault(); setParams(term ? { q: term } : {}); }}>
              <Search size={20} />
              <input value={term} onChange={(e) => setTerm(e.target.value)} placeholder="Try “Shiva”, “Varanasi” or “Tirumala”" />
              <button className="btn-primary">Search</button>
            </form>
          )}
        </div>
        {list === null ? <div className="page-loader">Loading…</div>
          : list.length === 0 ? <p className="empty">No temples found{q ? ` for “${q}”` : ''}.</p>
          : <div className="grid grid--3">{list.map((t) => <TempleCard key={t.id} temple={t} onChange={replace} />)}</div>}
      </div>
      <Footer />
    </div>
  );
}
