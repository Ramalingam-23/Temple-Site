import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../api';
import { fmtDate } from '../components/Cards';
import { Mail2 } from '../components/Icons';
import { useAuth } from '../context/AuthContext';

export default function ThankYou() {
  const { ref } = useParams();
  const { user } = useAuth();
  const [b, setB] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => { api.booking(ref).then(setB).catch((e) => setError(e.message)); }, [ref]);

  return (
    <div className="thanks">
      <div className="thanks__inner">
        <h1>Thank You!</h1>
        {error && <p>{error}</p>}
        {b && (
          <>
            <p>Your darshan at <strong>{b.temple_name}</strong> is confirmed.<br />
              {fmtDate(b.visit_date)} · {b.time_slot} · {b.devotees} devotee{b.devotees > 1 ? 's' : ''}</p>
            <div className="thanks__ref">Booking ID <strong>{b.booking_ref}</strong></div>
          </>
        )}
        <div className="thanks__actions">
          <Link to="/" className="btn-white">Back to Home</Link>
          {user && <Link to="/my-bookings" className="btn-ghost-dark">My Bookings</Link>}
        </div>
      </div>
      {b && <span className="thanks__mail"><Mail2 size={24} /> Show this Booking ID at the temple counter</span>}
    </div>
  );
}
