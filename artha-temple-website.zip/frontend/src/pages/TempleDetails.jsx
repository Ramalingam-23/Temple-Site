import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Img from '../components/Img';
import { toast } from '../components/Toast';
import { useAuth } from '../context/AuthContext';
import { api } from '../api';
import { Share, Bookmark, Heart, FileText, PlayCircle, Ticket, MapPin, TempleIcon, Landmark, Clock, Calendar, ArrowRight, Check } from '../components/Icons';

const PER_PAGE = 3;

export default function TempleDetails() {
  const { slug } = useParams();
  const nav = useNavigate();
  const { user } = useAuth();
  const [t, setT] = useState(null);
  const [error, setError] = useState('');
  const [expanded, setExpanded] = useState(false);
  const [page, setPage] = useState(0);

  useEffect(() => {
    setT(null); setPage(0);
    api.temple(slug).then(setT).catch((e) => setError(e.message));
  }, [slug]);

  const needLogin = () => {
    if (user) return false;
    toast('Please log in to use this feature.');
    nav('/login', { state: { from: `/temples/${slug}` } });
    return true;
  };
  const toggleBookmark = async () => {
    if (needLogin()) return;
    const { active } = await api.toggleBookmark(t.id);
    setT({ ...t, bookmarked: active }); toast(active ? 'Saved to your temples' : 'Removed from saved');
  };
  const toggleLike = async () => {
    if (needLogin()) return;
    const { active } = await api.toggleLike(t.id);
    setT({ ...t, liked: active, like_count: Number(t.like_count) + (active ? 1 : -1) });
  };
  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({ title: t.name, url });
      else { await navigator.clipboard.writeText(url); toast('Link copied to clipboard'); }
    } catch { /* user cancelled */ }
  };

  if (error) return <div className="page"><div className="detail-wrap"><Navbar /><p className="form-error">{error}</p></div></div>;
  if (!t) return <div className="page"><div className="detail-wrap"><Navbar /><div className="page-loader">Loading…</div></div></div>;

  const pages = Math.max(1, Math.ceil(t.rituals.length / PER_PAGE));
  const rituals = t.rituals.slice(page * PER_PAGE, page * PER_PAGE + PER_PAGE);
  const info = [
    { icon: MapPin, label: 'Location', value: t.location },
    { icon: TempleIcon, label: 'Deity', value: t.deity },
    { icon: Landmark, label: 'Established', value: t.established, note: t.established_note },
    { icon: Clock, label: 'Timings', value: t.timings, note: t.timings_note },
    { icon: Ticket, label: 'Entry Fee', value: t.entry_fee, note: t.entry_fee_note },
    { icon: Calendar, label: 'Best Time to Visit', value: t.best_time, note: t.best_time_note },
  ];

  return (
    <div className="page">
      <div className="detail-wrap">
        <Navbar />

        {/* ---------- Overview ---------- */}
        <section className="panel overview">
          <Img src={t.image} alt={t.name} className="overview__img" />
          <div className="overview__body">
            <h1>{t.name}</h1>
            <p className={expanded ? '' : 'clamp'}>{t.description}</p>
            <div className="overview__actions">
              <button className="btn-outline" onClick={() => { setExpanded(true); document.getElementById('rituals')?.scrollIntoView({ behavior: 'smooth' }); }}><FileText size={18} /> Read More</button>
              <button className="btn-outline" onClick={() => window.open(t.video_url, '_blank', 'noopener')}><PlayCircle size={18} /> Watch Videos</button>
              <button className="btn-outline" onClick={() => nav(`/book?temple=${t.id}`)}><Ticket size={18} /> Book Darshan</button>
            </div>
          </div>
          <div className="overview__icons">
            <button className="icon-btn" onClick={share} aria-label="Share"><Share size={18} /></button>
            <button className={`icon-btn ${t.bookmarked ? 'is-on' : ''}`} onClick={toggleBookmark} aria-label="Bookmark"><Bookmark size={18} fill={t.bookmarked ? 'currentColor' : 'none'} /></button>
            <button className={`icon-btn icon-btn--heart ${t.liked ? 'is-on' : ''}`} onClick={toggleLike} aria-label="Like" title={`${t.like_count} likes`}><Heart size={20} fill="currentColor" /></button>
          </div>
        </section>

        {/* ---------- Quick info ---------- */}
        <section className="panel">
          <h2 className="panel__title">Quick Information</h2>
          <div className="grid grid--3 info-grid">
            {info.map(({ icon: I, label, value, note }) => (
              <div className="info-card" key={label}>
                <h3><I size={22} /> {label}</h3>
                <p>{value}</p>
                {note && <small>{note}</small>}
              </div>
            ))}
          </div>
        </section>

        {/* ---------- Rituals ---------- */}
        <section className="panel" id="rituals">
          <h2 className="panel__title">Daily Rituals</h2>
          <div className="list">
            {rituals.map((r) => (
              <div className="list-card" key={r.id}>
                <h3><span className="emoji">{r.icon}</span> {r.title}{r.time_label ? ` - ${r.time_label}` : ''}</h3>
                <p>{r.description}</p>
              </div>
            ))}
          </div>
          {pages > 1 && (
            <div className="panel__foot">
              <span className="muted">{page + 1} / {pages}</span>
              <button className="icon-btn icon-btn--lg" onClick={() => setPage((p) => (p + 1) % pages)} aria-label="More rituals"><ArrowRight size={20} /></button>
            </div>
          )}
        </section>

        {/* ---------- Major festivals ---------- */}
        {t.festivals.length > 0 && (
          <section className="panel">
            <h2 className="panel__title">Major Festivals</h2>
            <div className="grid grid--3">
              {t.festivals.map((f) => (
                <div className="info-card info-card--left" key={f.id}>
                  <h3><Calendar size={20} /> {f.name}</h3>
                  <small className="tag">{f.period}</small>
                  <p className="info-card__desc">{f.description}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* ---------- Guidelines + nearby ---------- */}
        <div className="two-col">
          {t.guidelines.length > 0 && (
            <section className="panel">
              <h2 className="panel__title">Visitor Guidelines</h2>
              <ul className="checklist">
                {t.guidelines.map((g) => <li key={g.id}><span><Check size={14} sw={3} /></span>{g.text}</li>)}
              </ul>
            </section>
          )}
          {t.nearby.length > 0 && (
            <section className="panel">
              <h2 className="panel__title">Nearby Places</h2>
              <div className="list">
                {t.nearby.map((n) => (
                  <div className="list-card list-card--row" key={n.id}>
                    <div><h3><MapPin size={18} /> {n.name}</h3><p>{n.description}</p></div>
                    <span className="tag">{n.distance}</span>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
}
