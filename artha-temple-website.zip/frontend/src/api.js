// Small fetch wrapper for the Artha API (proxied to :5000 by Vite in dev)
const BASE = import.meta.env.VITE_API_URL || '/api';

export const tokenStore = {
  get: () => localStorage.getItem('artha_token') || sessionStorage.getItem('artha_token'),
  set: (t, remember) => {
    tokenStore.clear();
    (remember ? localStorage : sessionStorage).setItem('artha_token', t);
  },
  clear: () => { localStorage.removeItem('artha_token'); sessionStorage.removeItem('artha_token'); },
};

async function request(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const t = tokenStore.get();
  if (t) headers.Authorization = `Bearer ${t}`;
  const res = await fetch(BASE + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) { const err = new Error(data.message || 'Request failed'); err.status = res.status; throw err; }
  return data;
}

export const api = {
  signup: (b) => request('/auth/signup', { method: 'POST', body: b }),
  login: (b) => request('/auth/login', { method: 'POST', body: b }),
  me: () => request('/auth/me'),
  slides: () => request('/slides'),
  temples: (params = {}) => request('/temples?' + new URLSearchParams(params)),
  temple: (slug) => request(`/temples/${slug}`),
  toggleBookmark: (id) => request(`/temples/${id}/bookmark`, { method: 'POST' }),
  toggleLike: (id) => request(`/temples/${id}/like`, { method: 'POST' }),
  festivals: () => request('/festivals'),
  toggleReminder: (id) => request(`/festivals/${id}/remind`, { method: 'POST' }),
  myBookmarks: () => request('/me/bookmarks'),
  bookingOptions: () => request('/bookings/options'),
  createBooking: (b) => request('/bookings', { method: 'POST', body: b }),
  myBookings: () => request('/bookings/mine'),
  booking: (ref) => request(`/bookings/${ref}`),
  cancelBooking: (id) => request(`/bookings/${id}/cancel`, { method: 'PATCH' }),
};
