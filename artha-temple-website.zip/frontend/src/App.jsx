import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { useAuth } from './context/AuthContext';
import AuthPage from './pages/AuthPage';
import Home from './pages/Home';
import TempleDetails from './pages/TempleDetails';
import Discover from './pages/Discover';
import Services from './pages/Services';
import BookDarshan from './pages/BookDarshan';
import ThankYou from './pages/ThankYou';
import MyBookings from './pages/MyBookings';
import Toaster from './components/Toast';

function ScrollTop() {
  const { pathname } = useLocation();
  useEffect(() => window.scrollTo(0, 0), [pathname]);
  return null;
}

/** Signed-in users and guests may enter the site; everyone else goes to Login. */
function Gate({ children }) {
  const { user, guest, ready } = useAuth();
  if (!ready) return <div className="page-loader">Loading…</div>;
  return user || guest ? children : <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <>
      <ScrollTop />
      <Toaster />
      <Routes>
        <Route path="/login" element={<AuthPage mode="login" />} />
        <Route path="/signup" element={<AuthPage mode="signup" />} />
        <Route path="/" element={<Gate><Home /></Gate>} />
        <Route path="/discover" element={<Gate><Discover /></Gate>} />
        <Route path="/services" element={<Gate><Services /></Gate>} />
        <Route path="/temples/:slug" element={<Gate><TempleDetails /></Gate>} />
        <Route path="/book" element={<Gate><BookDarshan /></Gate>} />
        <Route path="/booking/:ref" element={<Gate><ThankYou /></Gate>} />
        <Route path="/my-bookings" element={<Gate><MyBookings /></Gate>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}
