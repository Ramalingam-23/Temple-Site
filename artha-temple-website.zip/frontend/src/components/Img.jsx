import { useState } from 'react';

/**
 * Image with a warm gradient fallback.
 * Drop your own photos into /public/images (see README for file names).
 */
export default function Img({ src, alt = '', className = '', style }) {
  const [failed, setFailed] = useState(!src);
  if (failed) {
    return (
      <div className={`img-fallback ${className}`} style={style} role="img" aria-label={alt}>
        <svg viewBox="0 0 200 120" preserveAspectRatio="xMidYMax meet" className="img-fallback__art">
          <path d="M100 8l-4 10h8zM88 20h24l3 12H85zM82 34h36l4 14H78zM74 50h52l5 18H69zM62 70h76l6 26H56z" fill="rgba(255,255,255,.18)" />
          <rect x="0" y="96" width="200" height="24" fill="rgba(0,0,0,.18)" />
        </svg>
      </div>
    );
  }
  return <img src={src} alt={alt} className={className} style={style} onError={() => setFailed(true)} loading="lazy" />;
}
