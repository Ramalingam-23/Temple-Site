import { useEffect, useState } from 'react';

/** Fire-and-forget toast: toast('Saved!') from anywhere. */
export const toast = (msg) => window.dispatchEvent(new CustomEvent('artha-toast', { detail: msg }));

export default function Toaster() {
  const [msg, setMsg] = useState(null);
  useEffect(() => {
    let t;
    const on = (e) => { setMsg(e.detail); clearTimeout(t); t = setTimeout(() => setMsg(null), 2800); };
    window.addEventListener('artha-toast', on);
    return () => window.removeEventListener('artha-toast', on);
  }, []);
  return msg ? <div className="toast" role="status">{msg}</div> : null;
}
