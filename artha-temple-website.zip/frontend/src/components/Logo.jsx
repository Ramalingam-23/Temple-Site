/** Artha mark: a gopuram (temple tower) rising from a lotus inside a circle. */
export function LogoMark({ size = 52, color = '#D97706', ring = '#E7C9A0', bg = 'transparent', lotus }) {
  const lotusFill = lotus || color;
  return (
    <svg width={size} height={size * 1.08} viewBox="0 0 64 69" aria-label="Artha logo">
      <circle cx="32" cy="32" r="30" fill={bg} stroke={ring} strokeWidth="2" />
      {/* kalasam dots */}
      {[24, 28, 32, 36, 40].map((x) => <circle key={x} cx={x} cy="12.5" r="1.4" fill={color} />)}
      {/* tiers */}
      <rect x="24" y="15" width="16" height="4.5" rx="0.6" fill={color} />
      <rect x="22" y="21" width="20" height="5" rx="0.6" fill={color} />
      <rect x="20" y="27.5" width="24" height="5.5" rx="0.6" fill={color} />
      <path d="M18 34.5h28V47H36v-6.5a4 4 0 0 0-8 0V47H18Z" fill={color} />
      {/* tier stripes */}
      {[[26, 17], [30, 17], [34, 17], [24, 23.5], [28, 23.5], [32, 23.5], [36, 23.5], [23, 30], [27, 30], [31, 30], [35, 30], [39, 30]].map(([x, y], i) => (
        <rect key={i} x={x} y={y} width="1.6" height="1.6" fill={bg === 'transparent' ? '#fff' : bg} opacity=".9" />
      ))}
      {/* lotus */}
      <g fill={lotusFill} stroke={bg === 'transparent' ? '#fff' : bg} strokeWidth="1.2">
        <path d="M32 47c-3 3-3.5 8 0 13 3.5-5 3-10 0-13Z" />
        <path d="M31 50c-4-2-9-1.5-11 2 1.5 5 6.5 8 12 8-2-3.5-2.5-7-1-10Z" />
        <path d="M33 50c4-2 9-1.5 11 2-1.5 5-6.5 8-12 8 2-3.5 2.5-7 1-10Z" />
        <path d="M22 54c-3 0-5 1-6 2.5 2.5 3 7 4.5 13 4-3-1.5-5.5-3.5-7-6.5Z" />
        <path d="M42 54c3 0 5 1 6 2.5-2.5 3-7 4.5-13 4 3-1.5 5.5-3.5 7-6.5Z" />
      </g>
    </svg>
  );
}

export function Logo({ light = false }) {
  return (
    <span className={`logo ${light ? 'logo--light' : ''}`}>
      <LogoMark size={52} color={light ? '#fff' : '#D97706'} ring={light ? 'rgba(255,255,255,.9)' : '#E7C9A0'} />
      <span className="logo__text">Artha</span>
    </span>
  );
}
