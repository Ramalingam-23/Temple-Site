import { Link } from 'react-router-dom';
import { LogoMark } from './Logo';
import { MapPin, Mail, Phone, FacebookSquare, InstagramIcon, YoutubeIcon } from './Icons';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer__inner">
        <div className="footer__brand">
          <LogoMark size={54} color="#fff" ring="#fff" bg="#2A231B" />
          <div>
            <h3>Artha</h3>
            <p>Preserving culture, simplifying temple experiences.</p>
          </div>
        </div>
        <div className="footer__cols">
          <div>
            <h4>Explore</h4>
            <Link to="/">Home</Link>
            <Link to="/discover">Temples</Link>
            <Link to="/#festivals">Festivals</Link>
            <Link to="/services">Services</Link>
            <Link to="/temples/kashi-vishwanath">About Kashi</Link>
            <Link to="/temples/vrindavan">About Vrindavan</Link>
            <Link to="/temples/tirumala">About Tirumala</Link>
          </div>
          <div>
            <h4>Services</h4>
            <Link to="/book">Darshan Booking</Link>
            <Link to="/services">Purohit Booking</Link>
            <Link to="/services">Seva Booking</Link>
            <Link to="/discover">Temple Information</Link>
            <Link to="/#festivals">Festival Stories</Link>
          </div>
          <div>
            <h4>Support</h4>
            <a href="#help">Help Center</a>
            <a href="#faqs">FAQs</a>
            <a href="mailto:hello@artha.in">Contact Us</a>
            <a href="#privacy">Privacy Policy</a>
            <a href="#terms">Terms &amp; Conditions</a>
          </div>
          <div>
            <h4>Contact</h4>
            <span className="footer__contact"><MapPin size={17} /> Bengaluru, India</span>
            <a className="footer__contact" href="mailto:hello@artha.in"><Mail size={17} /> hello@artha.in</a>
            <a className="footer__contact" href="tel:+919876543210"><Phone size={17} /> +91 98765 43210</a>
          </div>
          <div>
            <h4>Follow Us</h4>
            <div className="footer__social">
              <a href="#facebook" aria-label="Facebook"><FacebookSquare /></a>
              <a href="#instagram" aria-label="Instagram"><InstagramIcon /></a>
              <a href="#youtube" aria-label="YouTube"><YoutubeIcon /></a>
            </div>
          </div>
        </div>
        <p className="footer__copy">© {new Date().getFullYear()} Artha. All rights reserved.</p>
      </div>
    </footer>
  );
}
