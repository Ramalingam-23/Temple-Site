import { useNavigate } from 'react-router-dom';
import Img from './Img';
import { Bookmark, Bell, Calendar } from './Icons';
import { api } from '../api';
import { useAuth } from '../context/AuthContext';
import { toast } from './Toast';

export const fmtDate = (d) => { const [y, m, dd] = String(d).slice(0, 10).split('-'); return `${dd}-${m}-${y}`; };

function useNeedLogin() {
  const { user } = useAuth();
  const nav = useNavigate();
  return () => {
    if (user) return false;
    toast('Please log in to use this feature.');
    nav('/login', { state: { from: window.location.pathname } });
    return true;
  };
}

export function TempleCard({ temple, onChange }) {
  const nav = useNavigate();
  const needLogin = useNeedLogin();
  const toggle = async (e) => {
    e.stopPropagation();
    if (needLogin()) return;
    try {
      const { active } = await api.toggleBookmark(temple.id);
      onChange?.({ ...temple, bookmarked: active });
      toast(active ? `${temple.name} saved` : `${temple.name} removed from saved`);
    } catch (err) { toast(err.message); }
  };
  return (
    <article className="temple-card" onClick={() => nav(`/temples/${temple.slug}`)}>
      <Img src={temple.image} alt={temple.name} className="temple-card__img" />
      <div className="temple-card__shade" />
      <div className="temple-card__body">
        <div className="temple-card__title">
          <h3>{temple.name}</h3>
          <button className={`round-btn ${temple.bookmarked ? 'is-on' : ''}`} onClick={toggle} aria-label="Bookmark">
            <Bookmark size={18} fill={temple.bookmarked ? 'currentColor' : 'none'} />
          </button>
        </div>
        <p>{temple.short_desc}</p>
        <button className="btn-view" onClick={(e) => { e.stopPropagation(); nav(`/temples/${temple.slug}`); }}>View Details</button>
      </div>
    </article>
  );
}

export function FestivalCard({ fest, onChange }) {
  const needLogin = useNeedLogin();
  const toggle = async () => {
    if (needLogin()) return;
    try {
      const { active } = await api.toggleReminder(fest.id);
      onChange?.({ ...fest, reminded: active });
      toast(active ? `Reminder set for ${fest.name} 🔔` : `Reminder removed for ${fest.name}`);
    } catch (err) { toast(err.message); }
  };
  return (
    <article className="fest-card">
      <Img src={fest.image} alt={fest.name} className="fest-card__img" />
      <div className="fest-card__shade" />
      <button className={`round-btn fest-card__bell ${fest.reminded ? 'is-on' : ''}`} onClick={toggle} aria-label="Remind me">
        <Bell size={18} fill={fest.reminded ? 'currentColor' : 'none'} />
      </button>
      <div className="fest-card__body">
        <h3>{fest.name}</h3>
        <span className="fest-card__date"><Calendar size={18} /> {fmtDate(fest.fest_date)}</span>
        <p>{fest.description}</p>
      </div>
    </article>
  );
}
