import { useState, useRef, useEffect } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { Logo } from './Logo';
import { Search, User, LogOut, Ticket, Bookmark } from './Icons';
import { useAuth } from '../context/AuthContext';

export default function Navbar({ className = '' }) {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    const close = (e) => menuRef.current && !menuRef.current.contains(e.target) && setOpen(false);
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);

  const submit = (e) => { e.preventDefault(); nav(`/discover${q.trim() ? `?q=${encodeURIComponent(q.trim())}` : ''}`); };
  const initials = user?.fullName?.split(' ').map((s) => s[0]).slice(0, 2).join('').toUpperCase();

  return (
    <header className={`navbar ${className}`}>
      <Link to="/" className="navbar__brand"><Logo /></Link>
      <nav className="navbar__links">
        <NavLink to="/" end>Home</NavLink>
        <NavLink to="/discover">Discover</NavLink>
        <NavLink to="/services">Services</NavLink>
      </nav>
      <form className="navbar__search" onSubmit={submit}>
        <Search size={20} sw={2.4} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search" aria-label="Search temples" />
      </form>
      <div className="navbar__profile" ref={menuRef}>
        <button className="avatar" onClick={() => setOpen((o) => !o)} aria-label="Account menu">
          {user ? initials : <User size={20} />}
        </button>
        {open && (
          <div className="menu">
            {user ? (
              <>
                <div className="menu__head"><strong>{user.fullName}</strong><span>{user.email}</span></div>
                <Link to="/my-bookings" onClick={() => setOpen(false)}><Ticket size={16} /> My Bookings</Link>
                <Link to="/discover?saved=1" onClick={() => setOpen(false)}><Bookmark size={16} /> Saved Temples</Link>
                <button onClick={() => { logout(); nav('/login'); }}><LogOut size={16} /> Log out</button>
              </>
            ) : (
              <>
                <div className="menu__head"><strong>Guest</strong><span>Log in to save temples & bookings</span></div>
                <button onClick={() => { logout(); nav('/login'); }}><User size={16} /> Log in / Sign up</button>
              </>
            )}
          </div>
        )}
      </div>
    </header>
  );
}
