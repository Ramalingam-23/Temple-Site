import { useNavigate } from 'react-router-dom';
import Img from './Img';
import { ArrowRight } from './Icons';

const Flower = ({ className }) => (
  <svg className={className} viewBox="0 0 100 100" aria-hidden="true">
    {Array.from({ length: 12 }).map((_, i) => (
      <ellipse key={i} cx="50" cy="22" rx="9" ry="20" transform={`rotate(${i * 30} 50 50)`} fill="none" stroke="currentColor" strokeWidth="5" />
    ))}
    <circle cx="50" cy="50" r="12" fill="currentColor" />
  </svg>
);

export default function DarshanBanner() {
  const nav = useNavigate();
  return (
    <section className="section">
      <h2 className="section__title">Book For Darshan</h2>
      <div className="darshan">
        <Flower className="darshan__flower darshan__flower--tl" />
        <Flower className="darshan__flower darshan__flower--r" />
        <Flower className="darshan__flower darshan__flower--b" />
        <svg className="darshan__path" viewBox="0 0 800 300" preserveAspectRatio="none" aria-hidden="true">
          <path d="M20 250 C 200 270, 330 260, 330 180 C 330 110, 260 110, 250 170 C 240 240, 420 270, 520 200 C 600 150, 700 80, 790 40" />
        </svg>
        <div className="darshan__text">
          <h3>Experience a peaceful<br />and seamless darshan.</h3>
          <button className="btn-white" onClick={() => nav('/book')}>Book a ticket <ArrowRight size={20} /></button>
        </div>
        <div className="darshan__collage">
          <Img src="/images/darshan-2.jpg" alt="" className="darshan__img darshan__img--sm1" />
          <Img src="/images/darshan-1.jpg" alt="Temple darshan" className="darshan__img darshan__img--main" />
          <Img src="/images/darshan-3.jpg" alt="" className="darshan__img darshan__img--sm2" />
        </div>
      </div>
    </section>
  );
}
